#pragma once
#include "Game.h"
class Shader :
	public Game
{
private:
public:
	inline static unsigned int loadShader(string fileName);
};

