#pragma once
#include "headers.h"
using namespace std;

Object::Object()
{
	angle = 0;
	velocity = 0;
	mass = 0;
	bounciness[0] = 0;
	bounciness[1] = 0;
	bounciness[2] = 0;

	center = Point(0, 0);
	bounds[0] = Point(0, 0);
}

Object::Object(Point center, float mass, float bounciness[], float angle, float velocity)
{
	this->angle = angle;
	this->velocity = velocity;
	this->center = center;
	this->mass = mass;
	*(this->bounciness) = bounciness;
}

void Object::moveObject(float x, float y)
{
	int i = 0;
	do
	{
		bounds[i].movePoint(x, y);
		i++;
	} while (&bounds[i + 1] != nullptr);
}

void Object::addBound(Point nBound)
{

	
}

void Object::removeBound(int index)
{

}

Point Object::getBound(int index)
{
	return bounds[index];
}

float Object::returnPoints()
{
	float* points;
	int i = 0;
	int j = 0;

	if(&bounds[i]!=nullptr)
	do
	{
		i++;
	} while (&bounds[i] != nullptr);
	i++;

	points = new float[(2*i)];
	
	while (j < i)
	{
		points[j] = bounds[j].x;
		points[j + 1] = bounds[j].y;
		j += 2;
	}

	return *points;
}
