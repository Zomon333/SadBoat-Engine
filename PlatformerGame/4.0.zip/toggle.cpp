#pragma once
#include "headers.h"
using namespace std;

inline static void toggle(int index){
	keyPressed[index] = !keyPressed[index];
}