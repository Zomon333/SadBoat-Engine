#pragma once
#include "headers.h"
using namespace std;

inline static void setKey(int index, bool state)
{
	keyPressed[index] = state;
}
