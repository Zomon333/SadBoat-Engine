#pragma once
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <string>
#include <iostream>
#include <fstream>
#include <thread>
#include "Point.h"
#include "Line.h"
#include "Object.h"
#include "Keybinder.h"
using namespace std;


inline static void setKey(int index, bool state);

inline static bool getKey(int index);

inline static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);

inline static void error_callback(int error, const char* description);

inline static void toggle(int index);

inline static unsigned int compileShader(unsigned int type, const string& source);

inline static unsigned int createShader(const string& vertexShader, const string& fragmentShader);

int main();


