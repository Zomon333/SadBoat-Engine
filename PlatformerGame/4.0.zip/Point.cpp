#pragma once
#include "headers.h"
using namespace std;

Point::Point()
{
	x = 0;
	y = 0;
	//cout << "E\n";
}

Point::Point(float x, float y)
{
	this->x = x;
	this->y = y;
}

void Point::movePoint(float x, float y)
{
	this->x += x;
	this->y += y;
}


