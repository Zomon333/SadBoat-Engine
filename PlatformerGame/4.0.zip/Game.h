#pragma once
#include "headers.h"

class Game
{
private:
	static bool keyPressed[348];
	static Point cursorPos;
public:
	bool getKeyPressed(int key);
	void toggleKeyPress(int key);
	void setKeyPressed(int key, bool state);


};

