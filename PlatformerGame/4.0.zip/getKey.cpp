#pragma once
#include "headers.h"
using namespace std;

inline static bool getKey(int index)
{
	return keyPressed[index];
}