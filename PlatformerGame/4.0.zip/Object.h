#pragma once
#include "headers.h"
using namespace std;

class Object
{
private:
	float angle;
	float velocity;
	float mass;
	float* bounciness[3];

	int bound = 1;
	Point center;
	Point* vertexes;
	Point* bounds;
public:
	Object();
	Object(Point center, float mass, float bounciness[], float angle, float velocity);

	void moveObject(float x, float y);

	void addBound(Point nBound);
	void removeBound(int index);

	Point getBound(int index);

	float returnPoints();
	int getBoundCount()
	{
		return this->bound;
	}
	void setBoundCount(int bound)
	{
		this->bound = bound;
	}

};

