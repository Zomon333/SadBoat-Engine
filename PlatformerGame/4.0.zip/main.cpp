#pragma once
#include "headers.h"
using namespace std;

/*inline static unsigned int loadShader(string fileName)
{
	fstream file;
	file.open(fileName, 1);
	string workingMemory = "";
	string vs="";
	string fs="";
	bool vertex=false, fragment=false;
	if(file.is_open())
	while (file.get() != EOF)
	{
		file.unget();
		workingMemory += file.get();
		
		if (workingMemory == "\n" && !vertex && !fragment)
		{
			workingMemory = "";
		}
		if (workingMemory == "#END"||workingMemory=="#END")
		{
			vertex = false;
			fragment = false;
			workingMemory = "";
			cout << "#END\n";
		}
		else
		if (workingMemory == "#VERTEX\n")
		{
			vertex = true;
			fragment = false;
			workingMemory = "";
			cout << "#VERTEX\n";
		}
		else
		if (workingMemory == "#FRAGMENT\n")
		{
			fragment = true;
			vertex = false;
			workingMemory = "";
			cout << "#FRAGMENT\n";
		}
		else
		if (fragment)
		{
			file.unget();
			if (file.get() == '\n')
			{
				fs += workingMemory;
				workingMemory = "";
			}
			
		}
		else
		if (vertex)
		{
			file.unget();
			if (file.get() == '\n')
			{
				vs += workingMemory;
				workingMemory = "";
			}
		}

	}
	else
	{
		cout << "File did not open.";
	}

	unsigned int shader = createShader(vs, fs);
	return shader;
}

inline static unsigned int compileShader(unsigned int type, const string& source)
{
	unsigned int id = glCreateShader(type);
	const char* src = source.c_str();
	glShaderSource(id, 1, &src, nullptr);
	glCompileShader(id);

	int result;
	glGetShaderiv(id, GL_COMPILE_STATUS, &result);
	if (!result)
	{
		int length;
		glGetShaderiv(id, GL_INFO_LOG_LENGTH, &length);
		char* message = (char*)alloca(length * sizeof(char)); // This may have an issue. If so change char to char*
		glGetShaderInfoLog(id, length, &length, message);
		cout << "Failed to compile: " << ((type == GL_VERTEX_SHADER) ? "vertex" : "fragment") << endl << message << endl;
		glDeleteShader(id);
		return 0;
	}


	return id;
}

inline static unsigned int createShader(const string& vertexShader, const string& fragmentShader)
{
	unsigned int program = glCreateProgram();
	unsigned int vs = glCreateShader(GL_VERTEX_SHADER);
	unsigned int fs = glCreateShader(GL_FRAGMENT_SHADER);
	vs = compileShader(GL_VERTEX_SHADER, vertexShader);
	fs = compileShader(GL_FRAGMENT_SHADER, fragmentShader);

	glAttachShader(program, vs);
	glAttachShader(program, fs);
	glLinkProgram(program);
	glValidateProgram(program);

	glDeleteShader(vs);
	glDeleteShader(fs);

	return program;

}

inline static void error_callback(int error, const char* description)
{
	cout << "Error: " << glewGetErrorString(error) << ", " << description << endl;
}

inline static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	{
		if (key == -1 || key > 348)
			action = GLFW_DONT_CARE;
		if (action == GLFW_PRESS)
			keyPressed[key] = true;
		if (action == GLFW_RELEASE)
			keyPressed[key] = false;
	}
}

int main()
{
	

	int width = 640, height = 480;
	GLFWwindow* gameWindow;
	if (!glfwInit())
	{
		cout << "glfwInit() Failed.\n";
		return 0;
	}

	float ratio = width / height;


	glfwSetErrorCallback(error_callback);
	gameWindow = glfwCreateWindow(width, height, "", NULL, NULL);
	if (!gameWindow)
	{
		cout << "glfwCreateWindow() Failed.\n";
		glfwTerminate();
		return 0;
	}



	glfwMakeContextCurrent(gameWindow);
	

	glfwSetKeyCallback(gameWindow, key_callback);
	glfwSwapInterval(1);

	if (glewInit()!=GLEW_OK)
	{
		cout << "glewInit() Failed.\n";
		glfwTerminate();
		return 0;
	}

	float triangleb[6] =
	{
		0.97, 0.45,
		0.23, -0.72,
		-0.19, 3.7
	};


	static unsigned int bufferB;
	glGenBuffers(1, &bufferB);
	glBindBuffer(GL_ARRAY_BUFFER, bufferB); //Open buffer for editing?

	glBufferData(GL_ARRAY_BUFFER, (6 * sizeof(float)), triangleb, GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(float) * 2, 0);
	glBindBuffer(GL_VERTEX_ARRAY, 0); //Close buffer for editing?

	
	float triangle[6] =
	{
		-0.5, -0.5,
		0.0, 0.5,
		0.5, -0.5
	};


	static unsigned int bufferA;
	glGenBuffers(1, &bufferA);
	glBindBuffer(GL_ARRAY_BUFFER, bufferA); //Open buffer for editing?

	glBufferData(GL_ARRAY_BUFFER, (6 * sizeof(float)), triangle, GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(float) * 2, 0);
	glBindBuffer(GL_VERTEX_ARRAY, 0); //Close buffer for editing?

	unsigned int shader = loadShader("shaderb.shader");
	glUseProgram(shader);

	unsigned int* bufs = new unsigned int[2];
	bufs[1] = bufferA;
	bufs[2] = bufferB;

	while (!glfwWindowShouldClose(gameWindow))
	{
		glClear(GL_COLOR_BUFFER_BIT);
		glfwGetFramebufferSize(gameWindow, &width, &height);
		glViewport(0, 0, width, height);

		

		glfwGetCursorPos(gameWindow, &cursorPos.x, &cursorPos.y);
		cout << "X: " << cursorPos.x << " Y: " << cursorPos.y << endl;


		glDrawBuffers(2, bufs);
		
		//glDrawArrays(GL_TRIANGLES, 0, 3);
		//glDrawElements(GL_TRIANGLES, 2, GL_UNSIGNED_INT, 0);



		glfwSwapBuffers(gameWindow);
		glfwPollEvents();
	}

	return 1;
}
*/